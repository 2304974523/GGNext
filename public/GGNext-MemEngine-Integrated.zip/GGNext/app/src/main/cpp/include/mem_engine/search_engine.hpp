#pragma once
#ifndef MEM_ENGINE_SEARCH_ENGINE_HPP
#define MEM_ENGINE_SEARCH_ENGINE_HPP

#include "types.hpp"
#include "proc_io.hpp"
#include "maps_parser.hpp"
#include "mmap_store.hpp"
#include "simd_kernel.hpp"
#include <vector>
#include <string>
#include <cstdint>
#include <cstddef>

namespace mem_engine {

// ============================================================================
// Group Search Item Specification & Selectivity Scheduler
// ============================================================================
struct GroupFieldItem {
    DataType type      = DataType::INT32;
    int64_t  iVal      = 0;
    double   fVal      = 0.0;
    double   epsilon   = 1e-4;
    size_t   origIndex = 0; // Original index in user query (for ordered constraint)

    // Computes heuristic selectivity score: higher score = rarer pattern = better anchor
    uint32_t computeSelectivityScore() const noexcept;
};

struct GroupSearchQuery {
    std::vector<GroupFieldItem> fields;
    size_t                      maxSpanBytes = 512;  // e.g. A;B;C::512
    bool                        ordered      = true; // true: offset(f_0) < offset(f_1) < ...; false: any order within span
    bool                        aligned      = true; // align field checks to type width or 4B
};

// ============================================================================
// Telemetry & Diagnostics Structure for Automated QA & Benchmarking
// ============================================================================
struct ScanTelemetry {
    double   elapsedMs           = 0.0;
    size_t   totalVmasScanned    = 0;
    size_t   totalBytesScanned   = 0;
    size_t   readableBytes       = 0;
    size_t   guardPagesSkipped   = 0;
    size_t   candidatesFound     = 0;
    size_t   syscallsIssued      = 0;
    size_t   anchorFieldIndex    = 0; // For group search
    bool     spilledToMmap       = false;
};

// ============================================================================
// SearchEngine: Industrial-Grade Multi-Threaded Cross-Process Memory Scanner
// ============================================================================
class SearchEngine {
public:
    static constexpr size_t DEFAULT_CHUNK_SIZE = 4 * 1024 * 1024; // 4 MB per chunk task

    SearchEngine(ProcIO& io, size_t workerThreads = 4, const std::string& spillDir = "/tmp");
    ~SearchEngine() = default;

    SearchEngine(const SearchEngine&) = delete;
    SearchEngine& operator=(const SearchEngine&) = delete;

    void setRegionMask(uint32_t mask) noexcept { m_regionMask = mask; }
    uint32_t regionMask() const noexcept { return m_regionMask; }

    void setWorkerThreads(size_t count) noexcept { m_workerThreads = (count == 0) ? 1 : count; }
    size_t workerThreads() const noexcept { return m_workerThreads; }

    void setChunkSize(size_t chunkBytes) noexcept { m_chunkSize = (chunkBytes < 65536) ? 65536 : chunkBytes; }
    size_t chunkSize() const noexcept { return m_chunkSize; }

    // Refresh target process VMAs matching current region mask
    std::vector<VmaRegion> refreshRegions();
    void setCustomRegions(const std::vector<VmaRegion>& regions) { m_regions = regions; }
    const std::vector<VmaRegion>& regions() const noexcept { return m_regions; }

    // Access current candidate store & telemetry
    const MmapCandidateStore& candidates() const noexcept { return m_candidates; }
    MmapCandidateStore& candidates() noexcept { return m_candidates; }
    size_t candidateCount() const noexcept { return m_candidates.size(); }
    const ScanTelemetry& lastTelemetry() const noexcept { return m_lastTelemetry; }

    void clearSession() noexcept;

    // ------------------------------------------------------------------------
    // 1. Exact Search (Single-Type & Adaptive Multi-Type AUTO) + Refinement
    // ------------------------------------------------------------------------
    EngineErrc searchExact(
        DataType type,
        int64_t intTarget,
        double floatTarget,
        double epsilon = 1e-4,
        bool aligned = true,
        CancellationToken* token = nullptr,
        ProgressCallback progress = nullptr
    );

    EngineErrc refineExact(
        DataType type,
        int64_t intTarget,
        double floatTarget,
        double epsilon = 1e-4,
        CancellationToken* token = nullptr
    );

    // Byte[] (with optional mask) & UTF-8 / UTF-16 String Exact Search
    EngineErrc searchBytePattern(
        const std::vector<uint8_t>& pattern,
        const std::vector<uint8_t>& mask = {},
        CancellationToken* token = nullptr,
        ProgressCallback progress = nullptr
    );

    EngineErrc searchString(
        const std::string& utf8Str,
        bool utf16le = false,
        CancellationToken* token = nullptr,
        ProgressCallback progress = nullptr
    );

    // ------------------------------------------------------------------------
    // 2. Range Search ([Min, Max] Inclusive or (Min, Max) Exclusive) + Refine
    // ------------------------------------------------------------------------
    EngineErrc searchRange(
        DataType type,
        int64_t intMin,
        int64_t intMax,
        double floatMin,
        double floatMax,
        bool inclusive = true,
        bool aligned = true,
        CancellationToken* token = nullptr,
        ProgressCallback progress = nullptr
    );

    EngineErrc refineRange(
        DataType type,
        int64_t intMin,
        int64_t intMax,
        double floatMin,
        double floatMax,
        bool inclusive = true,
        CancellationToken* token = nullptr
    );

    // ------------------------------------------------------------------------
    // 3. Fuzzy / Delta Search (Unknown Initial Snapshot + State-Change Refine)
    // ------------------------------------------------------------------------
    EngineErrc startUnknownSnapshot(
        DataType type,
        CancellationToken* token = nullptr,
        ProgressCallback progress = nullptr
    );

    EngineErrc refineFuzzy(
        SearchOp deltaOp,
        int64_t intDelta = 0,
        double floatDelta = 0.0,
        double epsilon = 1e-4,
        CancellationToken* token = nullptr
    );

    // ------------------------------------------------------------------------
    // 4. Encoded & 6. XOR Search (Offset, Static XOR, XOR Pair 32/64, Addr XOR)
    // ------------------------------------------------------------------------
    EngineErrc searchEncoded(
        DataType type,
        EncodedMode mode,
        int64_t logicalInt,
        double logicalFloat,
        uint64_t keyOrMask = 0,
        bool aligned = true,
        CancellationToken* token = nullptr,
        ProgressCallback progress = nullptr
    );

    EngineErrc refineEncoded(
        DataType type,
        EncodedMode mode,
        int64_t logicalInt,
        double logicalFloat,
        uint64_t keyOrMask = 0,
        CancellationToken* token = nullptr
    );

    // ------------------------------------------------------------------------
    // 5. Group / Struct Search (Ordered & Unordered with Anchor Scheduling)
    // ------------------------------------------------------------------------
    EngineErrc searchGroup(
        const GroupSearchQuery& query,
        CancellationToken* token = nullptr,
        ProgressCallback progress = nullptr
    );

private:
    struct ChunkTask {
        uintptr_t startAddr   = 0;
        size_t    logicalLen  = 0; // Bytes belonging to this chunk [0, logicalLen)
        size_t    readLen     = 0; // logicalLen + overlapBytes (clamped to VMA end)
        uint32_t  regionFlag  = 0;
    };

    std::vector<ChunkTask> buildChunkTasks(size_t overlapBytes) const;

    static bool isRangeInValidPages(
        size_t offsetInChunk,
        size_t itemLen,
        uintptr_t chunkStartAddr,
        size_t pageSize,
        const std::vector<uint8_t>& validPageMask
    ) noexcept;

    static uint8_t regionFlagToIndex(uint32_t flag) noexcept;

    ProcIO&                  m_io;
    size_t                   m_workerThreads = 4;
    size_t                   m_chunkSize     = DEFAULT_CHUNK_SIZE;
    uint32_t                 m_regionMask    = RegionFlag::DEFAULT_RW;
    std::string              m_spillDir      = "/tmp";

    std::vector<VmaRegion>   m_regions;
    MmapCandidateStore       m_candidates;
    MmapRegionSnapshotStore  m_snapshotStore;
    bool                     m_hasFullSnapshot = false;
    DataType                 m_snapshotType    = DataType::INT32;
    ScanTelemetry            m_lastTelemetry{};
};

} // namespace mem_engine

#endif // MEM_ENGINE_SEARCH_ENGINE_HPP
