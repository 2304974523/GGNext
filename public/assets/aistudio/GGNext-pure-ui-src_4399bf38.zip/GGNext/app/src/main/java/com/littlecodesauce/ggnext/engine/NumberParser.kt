package com.littlecodesauce.ggnext.engine

import com.littlecodesauce.ggnext.model.ValueType

/**
 * 查询解析器。支持 GG 的输入语法：
 *  - 普通数字：123 / -100 / -4.5 / 0x1F / 1e9
 *  - 十六进制：1234h、h41424344
 *  - 文本：'abc'（UTF-8）、"abc"（UTF-16LE）、:abc、;abc
 *  - 范围：10~20、-50~50、100~~200（反向）
 *  - 联合：1;2;3 / 1;2;3:100（区域）
 *  - 异或：100X7
 *  - 类型后缀：10D、10F、10W、10B、10Q、10E、10X
 */
object NumberParser {

    class ParseException(message: String) : Exception(message)

    enum class Kind { NUMBER, TEXT, RANGE, GROUP }

    data class Query(
        val kind: Kind,
        val raw: String,
        val numbers: LongArray = LongArray(0),
        /** 每个数字的类型 flags */
        val types: IntArray = IntArray(0),
        /** 范围上界（仅 RANGE） */
        val to: LongArray = LongArray(0),
        val sign: Int = ValueType.SIGN_EQUAL,
        val xorKey: Int = 0,
        val area: Int = 0,
        val ordered: Boolean = false,
        val textBytes: ByteArray? = null,
        val textUtf16: Boolean = false
    ) {
        val baseType: Int get() = types.firstOrNull() ?: ValueType.AUTO
    }

    private val TYPE_SUFFIX = mapOf(
        'b' to ValueType.BYTE, 'w' to ValueType.WORD, 'd' to ValueType.DWORD,
        'x' to ValueType.XOR, 'f' to ValueType.FLOAT, 'q' to ValueType.QWORD,
        'e' to ValueType.DOUBLE, 'a' to ValueType.AUTO
    )

    fun isText(raw: String): Boolean {
        val t = raw.trim()
        return t.length > 1 && (t[0] == '\'' || t[0] == '"' || t[0] == ':' || t[0] == ';')
    }

    /** 解析一条完整输入（自动识别联合/范围/文本/异或） */
    fun parse(raw: String, defaultType: Int, sign: Int = ValueType.SIGN_EQUAL): Query {
        val input = raw.trim()
        if (input.isEmpty()) throw ParseException("请输入要搜索的值")

        if (isText(input)) {
            val utf16 = input[0] == '"' || input[0] == ';'
            val body = input.substring(1)
            val bytes = if (utf16) body.toByteArray(Charsets.UTF_16LE) else body.toByteArray(Charsets.UTF_8)
            if (bytes.isEmpty()) throw ParseException("文本不能为空")
            return Query(
                kind = Kind.TEXT, raw = input,
                numbers = LongArray(0), types = intArrayOf(if (utf16) ValueType.WORD else ValueType.BYTE),
                sign = sign, textBytes = bytes, textUtf16 = utf16
            )
        }

        if (input.contains(';')) return parseGroup(input, defaultType)
        if (input.contains('~')) return parseRange(input, defaultType, sign)

        var body = input
        var xorKey = 0
        val xIdx = body.indexOfFirst { it == 'X' || it == 'x' }
        if (xIdx > 0) {
            val keyText = body.substring(xIdx + 1)
            if (keyText.isNotEmpty() && keyText.all { it.isDigit() }) {
                xorKey = keyText.toIntOrNull() ?: throw ParseException("异或键无效: $keyText")
                if (xorKey < 1 || xorKey > 4096) throw ParseException("异或键必须在 1 - 4096 之间")
                body = body.substring(0, xIdx)
            }
        }

        val parsed = parseNumber(body, defaultType)
        return Query(
            kind = Kind.NUMBER, raw = input,
            numbers = longArrayOf(parsed.first), types = intArrayOf(parsed.second),
            sign = sign, xorKey = xorKey
        )
    }

    /** 单个数字解析，返回 (valueBits, typeFlags) */
    fun parseNumber(text: String, defaultType: Int): Pair<Long, Int> {
        var s = text.trim()
        if (s.isEmpty()) throw ParseException("数值为空")

        var type = defaultType
        val last = s.last().lowercaseChar()
        if (s.length > 1 && TYPE_SUFFIX.containsKey(last) && last !in "0123456789") {
            val suffixType = TYPE_SUFFIX.getValue(last)
            val candidate = s.dropLast(1)
            if (canParseNumber(candidate)) {
                type = if (defaultType == ValueType.AUTO) suffixType else (defaultType and suffixType).let { if (it == 0) suffixType else it }
                s = candidate
            }
        }

        // hex 后缀 1234h
        if (s.length > 1 && (s.last() == 'h' || s.last() == 'H')) {
            val hex = s.dropLast(1)
            val v = hex.toULongOrNull(16)?.toLong() ?: hex.toLongOrNull(16) ?: throw ParseException("无效的十六进制: $hex")
            return v to (if (defaultType == ValueType.AUTO) ValueType.DWORD else defaultType)
        }
        // h 前缀 h4100
        if (s.length > 1 && (s[0] == 'h' || s[0] == 'H')) {
            val hex = s.substring(1)
            val v = hex.toULongOrNull(16)?.toLong() ?: hex.toLongOrNull(16) ?: throw ParseException("无效的十六进制: $hex")
            return v to (if (defaultType == ValueType.AUTO) ValueType.DWORD else defaultType)
        }
        // 0x 前缀
        if (s.startsWith("0x", true)) {
            val hex = s.substring(2)
            val v = hex.toULongOrNull(16)?.toLong() ?: hex.toLongOrNull(16) ?: throw ParseException("无效的十六进制: $s")
            return v to (if (defaultType == ValueType.AUTO) ValueType.DWORD else defaultType)
        }

        val targetType = if (type == ValueType.AUTO) ValueType.DWORD else type
        return when (targetType and 0x7F) {
            ValueType.FLOAT -> {
                val f = s.replace(",", "").toFloatOrNull() ?: throw ParseException("无效的浮点数: $s")
                (f.toRawBits().toLong() and 0xFFFFFFFFL) to ValueType.FLOAT
            }
            ValueType.DOUBLE -> {
                val d = s.replace(",", "").toDoubleOrNull() ?: throw ParseException("无效的双精度数: $s")
                d.toRawBits() to ValueType.DOUBLE
            }
            ValueType.QWORD -> {
                val clean = s.replace(" ", "").replace(",", "")
                val v = clean.toLongOrNull() ?: clean.toULongOrNull()?.toLong()
                    ?: throw ParseException("无效的 64 位数值: $s")
                v to ValueType.QWORD
            }
            else -> {
                val clean = s.replace(" ", "").replace(",", "")
                val v = clean.toLongOrNull() ?: clean.toULongOrNull()?.toLong()
                    ?: throw ParseException("无效的数值: $s")
                validate(v, targetType)
                v to (targetType and 0x7F)
            }
        }
    }

    private fun canParseNumber(s: String): Boolean {
        val t = s.trim().replace(",", "")
        if (t.isEmpty()) return false
        return t.toDoubleOrNull() != null || t.removePrefix("0x").toLongOrNull(16) != null ||
            t.trimEnd('h', 'H').toLongOrNull(16) != null
    }

    private fun validate(v: Long, type: Int) {
        when (type and 0x7F) {
            ValueType.BYTE -> if (v < -128L || v > 255L) {
                throw ParseException("Byte 取值范围为 -128 ~ 255，当前: $v")
            }
            ValueType.WORD -> if (v < -32768L || v > 65535L) {
                throw ParseException("Word 取值范围为 -32,768 ~ 65,535，当前: $v")
            }
            ValueType.DWORD, ValueType.XOR -> if (v < -2147483648L || v > 4294967295L) {
                throw ParseException("Dword 取值范围为 -2,147,483,648 ~ 4,294,967,295，当前: $v")
            }
        }
    }

    private fun parseRange(input: String, defaultType: Int, sign: Int): Query {
        val inverted = input.contains("~~")
        val parts = input.split(if (inverted) "~~" else "~")
        if (parts.size != 2) throw ParseException("范围只能有两个边界值")
        val a = parseNumber(parts[0], defaultType)
        val b = parseNumber(parts[1], if (a.second == ValueType.AUTO) defaultType else a.second)
        if ((a.second and b.second) == 0) throw ParseException("范围的两个边界必须是同一类型")
        val type = a.second and b.second
        val s = if (inverted) ValueType.SIGN_NOT_EQUAL else sign
        return Query(
            kind = Kind.RANGE, raw = input,
            numbers = longArrayOf(a.first), to = longArrayOf(b.first),
            types = intArrayOf(type), sign = s
        )
    }

    private fun parseGroup(input: String, defaultType: Int): Query {
        val ordered = input.contains("::")
        val splitter = if (ordered) "::" else ":"
        val parts = input.split(splitter)
        var area = 512
        val listPart = parts[0]
        if (parts.size > 1) {
            area = parts[1].trim().toIntOrNull() ?: throw ParseException("区域大小无效: ${parts[1]}")
            if (area < 2 || area > 65536) throw ParseException("区域必须在 2 - 65,536 之间")
        }
        val items = listPart.split(';').map { it.trim() }.filter { it.isNotEmpty() }
        if (items.size < 2) throw ParseException("联合搜索至少需要两个数值")
        if (items.size > 32) throw ParseException("联合搜索最多 32 个数值")

        val values = LongArray(items.size)
        val types = IntArray(items.size)
        items.forEachIndexed { idx, item ->
            if (item.contains('~')) {
                val r = parseRange(item, defaultType, ValueType.SIGN_EQUAL)
                values[idx] = r.numbers[0]
                types[idx] = r.types[0]
            } else {
                val p = parseNumber(item, defaultType)
                values[idx] = p.first
                types[idx] = p.second
            }
        }
        return Query(
            kind = Kind.GROUP, raw = input, numbers = values, types = types,
            area = area, ordered = ordered
        )
    }

    /** 输入是否是合法十六进制串（用于 HEX 按钮转换） */
    fun isHex(text: String): Boolean = text.isNotEmpty() && text.all { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' }

    fun textToHex(text: String, utf16: Boolean = false): String {
        val bytes = if (utf16) text.toByteArray(Charsets.UTF_16LE) else text.toByteArray(Charsets.UTF_8)
        return bytes.joinToString(" ") { String.format("%02X", it) }
    }
}
