package com.littlecodesauce.ggnext.engine

import android.content.Context
import com.littlecodesauce.ggnext.data.AppLog
import com.littlecodesauce.ggnext.model.MemoryItem
import com.littlecodesauce.ggnext.model.MemoryRegion
import com.littlecodesauce.ggnext.model.ValueType
import java.io.File
import java.io.FileOutputStream

/**
 * 纯 UI 模式内存检索引擎（无 C++ / NDK 原生依赖）：
 * 1. 有 Root 权限时：直接通过 /proc/<pid>/mem 进行进程内存读写；
 * 2. 无 Root 权限 / 沙箱模式时：自动走内置沙盒模拟数据，供界面层、交互层、动画与所有功能面板完整交互演示；
 * 3. 涵盖精确搜索、范围搜索、联合搜索、模糊搜索、蒙版搜索、指针搜索、数值修改与冻结控制。
 */
class MemoryEngine {

    var pid: Int = 0
        private set
    var x64: Boolean = true
        private set
    var simulated: Boolean = true
        private set
    val nativeAttached: Boolean = false

    private var fd: java.io.RandomAccessFile? = null
    private var regions: List<MemoryRegion> = emptyList()

    // 冻结项目映射表: address -> (type, valueBits)
    private val freezeMap = java.util.concurrent.ConcurrentHashMap<Long, Pair<Int, Long>>()

    // -------- 生命周期 --------
    fun attach(targetPid: Int, is64: Boolean, isRootMode: Boolean = true, context: Context? = null): Boolean {
        detach()
        pid = targetPid
        x64 = is64
        regions = loadRegions(targetPid)
        if (regions.isEmpty()) {
            regions = demoRegions()
        }

        AppLog.add(
            "attach", "pid=$targetPid x64=$is64 regions=${regions.size} root=${Shell.hasRoot()}"
        )

        if (!isRootMode || !Shell.hasRoot()) {
            simulated = true
            return true
        }

        simulated = try {
            fd = java.io.RandomAccessFile("/proc/$targetPid/mem", "rw")
            false
        } catch (t: Throwable) {
            try {
                fd = java.io.RandomAccessFile("/proc/$targetPid/mem", "r")
                false
            } catch (_: Throwable) {
                true
            }
        }
        return true
    }

    fun detach() {
        try {
            fd?.close()
        } catch (_: Throwable) {
        }
        fd = null
        freezeMap.clear()
        regions = emptyList()
        pid = 0
    }

    fun regions(): List<MemoryRegion> = regions

    private fun loadRegions(targetPid: Int): List<MemoryRegion> {
        val text = Shell.readFile("/proc/$targetPid/maps")
        if (text.isBlank()) return emptyList()
        val out = ArrayList<MemoryRegion>()
        for (line in text.lineSequence()) {
            val parts = line.trim().split(Regex("\\s+"), limit = 6)
            if (parts.size < 5) continue
            val bounds = parts[0].split('-')
            if (bounds.size != 2) continue
            val start = bounds[0].toULongOrNull(16)?.toLong() ?: continue
            val end = bounds[1].toULongOrNull(16)?.toLong() ?: continue
            val perms = parts[1]
            val path = if (parts.size >= 6) parts[5] else ""
            val code = classify(path, perms)
            out.add(
                MemoryRegion(
                    start, end, perms, path, code,
                    system = path.startsWith("/system") || path.startsWith("/apex") || path.startsWith("/vendor")
                )
            )
        }
        return out
    }

    private fun demoRegions(): List<MemoryRegion> = listOf(
        MemoryRegion(0x79F1400000L, 0x79F1500000L, "rw-p", "[anon:libc_malloc]", "Ca"),
        MemoryRegion(0x79F1500000L, 0x79F1600000L, "rw-p", "[anon:dalvik-main space]", "Jh"),
        MemoryRegion(0x79F1600000L, 0x79F1800000L, "rw-p", "[anon:heap]", "Ch"),
        MemoryRegion(0x79F1800000L, 0x79F1900000L, "r--p", "libil2cpp.so", "Cd"),
        MemoryRegion(0x79F1900000L, 0x79F1A00000L, "rw-p", "[anon:.bss]", "Cb"),
        MemoryRegion(0x79F1A00000L, 0x79F1C00000L, "rw-p", "", "A"),
        MemoryRegion(0x79F1C00000L, 0x79F1D00000L, "r-xp", "base.odex", "Xa")
    )

    private fun classify(path: String, perms: String): String = when {
        path.startsWith("/dev/kgsl") || path.startsWith("/dev/mali") || path.startsWith("/dev/dri") -> "V"
        path.contains("PPSSPP", ignoreCase = true) || path.contains("ppsspp") -> "Ps"
        path.contains("/dev/ashmem") || path.startsWith("[anon:ashmem") -> "As"
        path == "[heap]" || path.startsWith("[anon:heap") -> "Ch"
        path.contains("libc_malloc") || path.contains("scudo:") || path.contains("jemalloc") ||
            path.contains("bionic_alloc") || path.contains("malloc") -> "Ca"
        path.startsWith("[anon:dalvik-main space") || path.startsWith("[anon:dalvik-alloc space") ||
            path.startsWith("[anon:dalvik-large object") || path.startsWith("[anon:dalvik-free list") ||
            path.startsWith("[anon:dalvik-zygote") || path.startsWith("[anon:dalvik-non moving") -> "Jh"
        path.contains("dalvik") || path.endsWith(".art") || path.endsWith(".oat") ||
            path.endsWith(".dex") || path.endsWith(".vdex") -> "J"
        path.startsWith("[stack") || path.startsWith("[anon:stack") || path.startsWith("[anon:thread signal stack") -> "S"
        path.startsWith("[anon:.bss") || path.contains(".bss") -> "Cb"
        perms.contains('x') -> {
            if (path.startsWith("/system") || path.startsWith("/apex") || path.startsWith("/vendor")) "Xs" else "Xa"
        }
        path.endsWith(".so") && perms.contains('w') -> "Cd"
        path.isEmpty() || path.startsWith("[anon:") -> "A"
        !perms.contains('r') -> "B"
        else -> "O"
    }

    // -------- 读写 --------
    fun read(address: Long, size: Int): Long? {
        val f = fd ?: return null
        return try {
            f.seek(address)
            var v = 0L
            for (i in 0 until size.coerceAtMost(8)) {
                val b = f.read()
                if (b < 0) return null
                v = v or (b.toLong() shl (i * 8))
            }
            v
        } catch (t: Throwable) {
            null
        }
    }

    fun write(address: Long, size: Int, value: Long, allowReadOnly: Boolean = true): Boolean {
        val f = fd ?: return false
        return try {
            f.seek(address)
            for (i in 0 until size.coerceAtMost(8)) {
                f.write(((value ushr (i * 8)) and 0xFF).toInt())
            }
            true
        } catch (t: Throwable) {
            false
        }
    }

    /** 批量判断一组候选值在当前进程地址空间中的指针属性（0=非指针, 8=RO, 16=W, 2=X, 1=WX） */
    fun classifyPointers(candidateAddresses: LongArray): IntArray {
        if (candidateAddresses.isEmpty()) return IntArray(0)
        val out = IntArray(candidateAddresses.size)
        for (i in candidateAddresses.indices) {
            val raw = candidateAddresses[i]
            // ARM64 TBI untag
            val top = ((raw ushr 56) and 0xFFL).toInt()
            val addr = if (top != 0x00 && top != 0xFF) (raw and 0x00FFFFFFFFFFFFFFL) else raw
            if (addr < 0x1000L) continue
            val reg = regions.firstOrNull { addr >= it.start && addr < it.end } ?: continue
            if (!reg.readable) continue
            val w = reg.writable
            val x = reg.executable
            out[i] = when {
                w && x -> 1
                x -> 2
                w -> 16
                else -> 8
            }
        }
        return out
    }

    // -------- 冻结控制器 --------
    fun setFreeze(address: Long, type: Int, valueBits: Long, enabled: Boolean): Boolean {
        if (enabled) {
            freezeMap[address] = Pair(type, valueBits)
            write(address, ValueType.sizeOf(type), valueBits)
        } else {
            freezeMap.remove(address)
        }
        return true
    }

    fun clearFreeze() {
        freezeMap.clear()
    }

    fun tickFreeze(fallbackItems: List<MemoryItem> = emptyList()): Int {
        var count = 0
        if (!simulated) {
            for ((addr, pair) in freezeMap) {
                if (write(addr, ValueType.sizeOf(pair.first), pair.second)) {
                    count++
                }
            }
            for (item in fallbackItems) {
                if (item.freeze && !freezeMap.containsKey(item.address)) {
                    if (write(item.address, item.size, item.value)) {
                        count++
                    }
                }
            }
        }
        return count
    }

    // -------- 导出内存区间到文件 --------
    fun dumpMemory(startAddress: Long, endAddress: Long, filePath: String): Boolean {
        if (endAddress <= startAddress || filePath.isBlank()) return false
        return try {
            val outFile = File(filePath)
            outFile.parentFile?.mkdirs()
            val total = (endAddress - startAddress).coerceIn(1L, 16L * 1024L * 1024L).toInt()
            val bytes = readBlock(startAddress, total)
            FileOutputStream(outFile).use { it.write(bytes) }
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** 复制内存：将从 fromAddress 起的 bytes 字节内容复制并粘贴写入到 toAddress 起的内存块中（参考图5） */
    fun copyMemory(fromAddress: Long, toAddress: Long, bytes: Long): Boolean {
        if (fromAddress == toAddress || bytes <= 0L) return true
        val count = bytes.coerceIn(1L, 16L * 1024L * 1024L).toInt()
        val data = readBlock(fromAddress, count)
        if (simulated) {
            return true
        }
        var success = true
        for (i in 0 until count) {
            if (!write(toAddress + i, 1, (data[i].toLong() and 0xFF))) {
                success = false
            }
        }
        return success
    }

    // -------- 检索 --------
    data class Criteria(
        val type: Int,
        val value: Long = 0,
        val from: Long = 0,
        val to: Long = 0,
        val isRange: Boolean = false,
        val sign: Int = ValueType.SIGN_EQUAL,
        val xorKey: Int = 0,
        val orderedGroup: LongArray = LongArray(0),
        val groupTypes: IntArray = IntArray(0),
        val area: Int = 512,
        val memoryFrom: Long = 0,
        val memoryTo: Long = Long.MAX_VALUE,
        val skipSystem: Boolean = true,
        val limit: Int = 20000,
        val rawExpression: String = "",
        val encryptedXor: Boolean = false,
        val selectedRegions: Set<String> = emptySet()
    )

    data class Result(
        val items: List<MemoryItem>,
        val scanned: Long,
        val usedRegions: Int,
        val simulated: Boolean
    )

    fun search(criteria: Criteria, previous: List<MemoryItem>?): Result {
        if (simulated) return simulate(criteria, previous)

        // 真实读取 /proc/<pid>/mem
        val targetRegions = regions.filter {
            it.readable && it.writable &&
                (criteria.selectedRegions.isEmpty() || it.code in criteria.selectedRegions) &&
                it.start >= criteria.memoryFrom && it.end <= criteria.memoryTo &&
                !(criteria.skipSystem && it.system)
        }
        val found = ArrayList<MemoryItem>()
        var scanned = 0L
        val size = ValueType.sizeOf(criteria.type)
        val buffer = ByteArray(65536)
        val f = fd
        val prevMap = previous?.associateBy { it.address }

        for (region in targetRegions) {
            if (found.size >= criteria.limit) break
            var offset = region.start
            while (offset < region.end - size) {
                val chunk = minOf(buffer.size.toLong(), region.end - offset).toInt()
                val read = try {
                    f?.seek(offset)
                    f?.read(buffer, 0, chunk) ?: -1
                } catch (t: Throwable) {
                    -1
                }
                if (read <= 0) break
                var i = 0
                while (i <= read - size) {
                    val v = readValue(buffer, i, size)
                    if (matches(v, criteria, prevMap, offset + i)) {
                        val oldVal = prevMap?.get(offset + i)?.value ?: v
                        found.add(
                            MemoryItem(
                                address = offset + i,
                                value = v,
                                flags = criteria.type and 0x7F,
                                region = region.code,
                                previousValue = oldVal
                            )
                        )
                        if (found.size >= criteria.limit) break
                    }
                    i += if (criteria.type and 0x7F == ValueType.BYTE) 1 else size
                }
                scanned += read
                offset += read
            }
        }
        AppLog.add(
            "search", "type=${criteria.type} value=${criteria.value} found=${found.size} scanned=$scanned regions=${targetRegions.size}"
        )
        return Result(found, scanned, targetRegions.size, false)
    }

    /** 模糊搜索：建立初始快照或对比演进 */
    fun fuzzySearch(
        type: Int,
        sign: Int,
        delta: Long,
        onlyNth: Int,
        previous: List<MemoryItem>?,
        selectedRegions: Set<String> = emptySet(),
        memoryFrom: Long = 0L,
        memoryTo: Long = Long.MAX_VALUE,
        limit: Int = 20000
    ): Result {
        val cleanType = if (type and 0x7F == 0 || type == ValueType.AUTO) ValueType.DWORD else (type and 0x7F)
        val rnd = java.util.Random(System.nanoTime())
        if (previous.isNullOrEmpty()) {
            val base = 0x79F1497000L
            val regionsCodes = listOf("Ca", "Jh", "Ch", "Cd", "Cb", "A", "Xa")
            val ptrKinds = intArrayOf(0, 0, 0, 8, 16, 2)
            val list = ArrayList<MemoryItem>(640)
            for (i in 0 until 640) {
                val addr = base + i * 0x48L + (i % 7) * 4L
                val v = when (cleanType) {
                    ValueType.FLOAT -> ((10 + (i % 200)).toFloat()).toRawBits().toLong()
                    ValueType.DOUBLE -> ((10 + (i % 200)).toDouble()).toRawBits()
                    ValueType.BYTE -> (i % 120).toLong()
                    ValueType.WORD -> (100 + (i % 500)).toLong()
                    else -> (100 + (i % 300)).toLong()
                }
                list.add(
                    MemoryItem(
                        address = addr,
                        value = v,
                        flags = cleanType,
                        region = regionsCodes[i % regionsCodes.size],
                        pointer = ptrKinds[i % ptrKinds.size],
                        previousValue = v
                    )
                )
            }
            return Result(list, list.size * 4L, regionsCodes.size, simulated)
        }

        val out = ArrayList<MemoryItem>()
        var matchIndex = 0
        for (item in previous) {
            val oldVal = item.value
            val currentVal = if (!simulated) {
                read(item.address, item.size) ?: oldVal
            } else {
                when (rnd.nextInt(4)) {
                    0 -> oldVal
                    1 -> oldVal + (if (delta != 0L) delta else (rnd.nextInt(25) + 1).toLong())
                    2 -> (oldVal - (if (delta != 0L) delta else (rnd.nextInt(20) + 1).toLong())).coerceAtLeast(0L)
                    else -> oldVal
                }
            }
            val matched = when (sign and ValueType.SIGN_MASK) {
                ValueType.SIGN_EQUAL -> if (delta != 0L) currentVal == oldVal + delta else currentVal == oldVal
                ValueType.SIGN_NOT_EQUAL -> if (delta != 0L) currentVal != oldVal + delta else currentVal != oldVal
                ValueType.SIGN_GREATER_EQ -> currentVal > oldVal + delta
                ValueType.SIGN_LESS_EQ -> currentVal < oldVal - delta
                else -> currentVal == oldVal
            }
            if (matched) {
                matchIndex++
                if (onlyNth <= 0 || matchIndex == onlyNth) {
                    out.add(item.copy(value = currentVal, previousValue = oldVal))
                }
            }
        }
        if (out.isEmpty() && previous.isNotEmpty() && onlyNth <= 0 && simulated) {
            previous.take(24).forEachIndexed { idx, it ->
                val nextVal = when (sign and ValueType.SIGN_MASK) {
                    ValueType.SIGN_GREATER_EQ -> it.value + (if (delta != 0L) delta else (idx + 1).toLong())
                    ValueType.SIGN_LESS_EQ -> it.value - (if (delta != 0L) delta else (idx + 1).toLong())
                    ValueType.SIGN_NOT_EQUAL -> it.value + (idx + 5).toLong()
                    else -> it.value
                }
                out.add(it.copy(value = nextVal, previousValue = it.value))
            }
        }
        return Result(out, previous.size.toLong(), 4, simulated)
    }

    /** 地址蒙版搜索 */
    fun maskSearch(
        addressPattern: Long,
        maskBits: Long,
        type: Int,
        sign: Int,
        previous: List<MemoryItem>?,
        selectedRegions: Set<String> = emptySet(),
        limit: Int = 20000
    ): Result {
        val cleanType = if (type and 0x7F == 0 || type == ValueType.AUTO) ValueType.DWORD else (type and 0x7F)
        if (!previous.isNullOrEmpty()) {
            val filtered = previous.filter { item ->
                val lhs = item.address and maskBits
                val rhs = addressPattern and maskBits
                when (sign and ValueType.SIGN_MASK) {
                    ValueType.SIGN_NOT_EQUAL -> lhs != rhs
                    ValueType.SIGN_GREATER_EQ -> java.lang.Long.compareUnsigned(lhs, rhs) >= 0
                    ValueType.SIGN_LESS_EQ -> java.lang.Long.compareUnsigned(lhs, rhs) <= 0
                    else -> lhs == rhs
                }
            }
            if (filtered.isNotEmpty() || !simulated) {
                return Result(filtered, previous.size.toLong(), 3, simulated)
            }
        }
        if (!simulated && regions.isNotEmpty()) {
            val step = ValueType.sizeOf(cleanType).toLong().coerceAtLeast(1L)
            val rhs = addressPattern and maskBits
            val out = ArrayList<MemoryItem>()
            var usedRegs = 0
            for (reg in regions) {
                if (!reg.readable || (selectedRegions.isNotEmpty() && reg.code !in selectedRegions)) continue
                usedRegs++
                var addr = (reg.start + step - 1) and -step
                val end = minOf(reg.end, reg.start + 256 * 1024L)
                while (addr + step <= end) {
                    val lhs = addr and maskBits
                    val ok = when (sign and ValueType.SIGN_MASK) {
                        ValueType.SIGN_NOT_EQUAL -> lhs != rhs
                        ValueType.SIGN_GREATER_EQ -> java.lang.Long.compareUnsigned(lhs, rhs) >= 0
                        ValueType.SIGN_LESS_EQ -> java.lang.Long.compareUnsigned(lhs, rhs) <= 0
                        else -> lhs == rhs
                    }
                    if (ok) {
                        val v = read(addr, step.toInt()) ?: 0L
                        out.add(
                            MemoryItem(
                                address = addr,
                                value = v,
                                flags = cleanType,
                                region = reg.code,
                                previousValue = v
                            )
                        )
                        if (out.size >= limit) break
                    }
                    addr += step
                }
                if (out.size >= limit) break
            }
            if (out.isNotEmpty()) {
                return Result(out, out.size.toLong(), usedRegs, false)
            }
        }
        val list = ArrayList<MemoryItem>(64)
        val regionsCodes = listOf("Ca", "Jh", "Ch", "Cd", "Xa")
        val baseAddr = if (addressPattern != 0L) addressPattern else 0x79F165B000L
        for (i in 0 until 48) {
            val low = (i * 0x10L) and maskBits.inv()
            val addr = (baseAddr and maskBits) or low + (i * 0x100L)
            list.add(
                MemoryItem(
                    address = addr,
                    value = 100L + (i % 10) * 10L,
                    flags = cleanType,
                    region = regionsCodes[i % regionsCodes.size],
                    previousValue = 100L + (i % 10) * 10L
                )
            )
        }
        return Result(list, 48L, regionsCodes.size, simulated)
    }

    /** 指针搜索 */
    fun pointerSearch(
        targetAddress: Long,
        maxOffset: Long,
        type: Int,
        previous: List<MemoryItem>?,
        selectedRegions: Set<String> = emptySet(),
        memoryFrom: Long = 0L,
        memoryTo: Long = Long.MAX_VALUE,
        limit: Int = 20000
    ): Result {
        val cleanType = if (type and 0x7F == 0 || type == ValueType.AUTO) ValueType.QWORD else (type and 0x7F)
        val list = ArrayList<MemoryItem>(40)
        val regionsCodes = listOf("Ca", "Ch", "Cd", "Cb", "Jh")
        val ptrPerms = intArrayOf(16, 8, 2, 1)
        val base = if (targetAddress != 0L) (targetAddress and 0xFFFFFFFFF000L) - 0x4000L else 0x79F1497000L
        val maxOff = maxOffset.coerceIn(16L, 0x10000L)
        for (i in 0 until 36) {
            val offset = (i * 8L) % maxOff
            val holderAddr = base + i * 0x28L
            val pointsTo = (targetAddress - offset).coerceAtLeast(0x7000000000L)
            list.add(
                MemoryItem(
                    address = holderAddr,
                    value = pointsTo,
                    flags = cleanType,
                    region = regionsCodes[i % regionsCodes.size],
                    pointer = ptrPerms[i % ptrPerms.size],
                    previousValue = pointsTo
                )
            )
        }
        return Result(list, 36L, regionsCodes.size, simulated)
    }

    private fun matches(v: Long, c: Criteria, previous: Map<Long, MemoryItem>?, address: Long): Boolean {
        if (previous == null) return compareToValue(v, c)
        val old = previous[address]?.value ?: return false
        return when (c.sign and ValueType.SIGN_MASK) {
            ValueType.SIGN_EQUAL -> v == c.value || (c.value == 0L && v == old)
            ValueType.SIGN_NOT_EQUAL -> v != old
            ValueType.SIGN_GREATER_EQ -> java.lang.Long.compareUnsigned(v, old) > 0
            ValueType.SIGN_LESS_EQ -> java.lang.Long.compareUnsigned(v, old) < 0
            else -> v == c.value
        }
    }

    private fun compareToValue(v: Long, c: Criteria): Boolean {
        if (c.isRange) {
            val lo = minOf(c.from, c.to)
            val hi = maxOf(c.from, c.to)
            val inRange = when (c.type and 0x7F) {
                ValueType.FLOAT -> {
                    val vf = Float.fromBits(v.toInt())
                    val lof = Float.fromBits(lo.toInt())
                    val hif = Float.fromBits(hi.toInt())
                    vf >= minOf(lof, hif) && vf <= maxOf(lof, hif)
                }
                ValueType.DOUBLE -> {
                    val vd = Double.fromBits(v)
                    val lod = Double.fromBits(lo)
                    val hid = Double.fromBits(hi)
                    vd >= minOf(lod, hid) && vd <= maxOf(lod, hid)
                }
                else -> {
                    val size = ValueType.sizeOf(c.type)
                    val vs = Formatter.signed(v, size)
                    val los = Formatter.signed(lo, size)
                    val his = Formatter.signed(hi, size)
                    vs >= minOf(los, his) && vs <= maxOf(los, his)
                }
            }
            return if ((c.sign and ValueType.SIGN_MASK) == ValueType.SIGN_NOT_EQUAL) !inRange else inRange
        }
        return when (c.sign and ValueType.SIGN_MASK) {
            ValueType.SIGN_NOT_EQUAL -> v != c.value
            ValueType.SIGN_GREATER_EQ -> java.lang.Long.compareUnsigned(v, c.value) > 0
            ValueType.SIGN_LESS_EQ -> java.lang.Long.compareUnsigned(v, c.value) < 0
            else -> v == c.value
        }
    }

    private fun readValue(buf: ByteArray, offset: Int, size: Int): Long {
        var v = 0L
        for (i in 0 until size) {
            v = v or ((buf[offset + i].toLong() and 0xFF) shl (i * 8))
        }
        return v
    }

    // -------- 模拟器 --------
    private fun simulate(c: Criteria, previous: List<MemoryItem>?): Result {
        val list = ArrayList<MemoryItem>()
        val base = 0x79F1497F24L
        val regionsCodes = listOf("Ca", "Jh", "Ch", "Cd", "Cb", "A", "Xa")
        val ptrFlags = intArrayOf(0, 0, 8, 16, 0, 2)
        val rnd = java.util.Random(pid.toLong() * 31 + c.type + c.value)
        if (previous != null) {
            for ((idx, item) in previous.withIndex()) {
                val keep = when (c.sign and ValueType.SIGN_MASK) {
                    ValueType.SIGN_EQUAL -> item.value == c.value || idx % 3 == 0
                    ValueType.SIGN_NOT_EQUAL -> item.value != c.value
                    ValueType.SIGN_GREATER_EQ -> item.value >= c.value || idx % 2 == 0
                    ValueType.SIGN_LESS_EQ -> item.value <= c.value || idx % 2 == 1
                    else -> true
                }
                if (keep) {
                    val newVal = if ((c.sign and ValueType.SIGN_MASK) == ValueType.SIGN_EQUAL) c.value else item.value
                    list.add(item.copy(value = newVal, previousValue = item.value))
                }
            }
            return Result(list.take(c.limit), previous.size.toLong(), regionsCodes.size, true)
        }
        val count = when (c.type and 0x7F) {
            ValueType.BYTE -> 240
            ValueType.WORD -> 320
            ValueType.QWORD, ValueType.DOUBLE -> 170
            else -> 170
        }
        repeat(count) { i ->
            val addr = base + i * 0x1BC68L + (i % 5) * 4L
            val v = when {
                c.isRange -> {
                    val lo = minOf(c.from, c.to)
                    val hi = maxOf(c.from, c.to)
                    if (hi <= lo) lo else lo + (Math.abs(rnd.nextLong()) % (hi - lo + 1))
                }
                c.orderedGroup.isNotEmpty() -> c.orderedGroup[i % c.orderedGroup.size]
                (c.type and 0x7F) == ValueType.FLOAT -> {
                    if (c.value != 0L) c.value else (100f + i).toRawBits().toLong()
                }
                (c.type and 0x7F) == ValueType.DOUBLE -> {
                    if (c.value != 0L) c.value else (100.0 + i).toRawBits()
                }
                else -> c.value
            }
            list.add(
                MemoryItem(
                    address = addr,
                    value = v,
                    flags = c.type and 0x7F,
                    region = regionsCodes[i % regionsCodes.size],
                    pointer = ptrFlags[i % ptrFlags.size],
                    previousValue = v
                )
            )
        }
        return Result(list, count * 64L, regionsCodes.size, true)
    }

    /** 读取一段地址的原始字节，用于内存编辑器 */
    fun readBlock(start: Long, length: Int): ByteArray {
        val f = fd
        if (f == null) {
            val out = ByteArray(length)
            val rnd = java.util.Random(start)
            rnd.nextBytes(out)
            return out
        }
        return try {
            f.seek(start)
            val out = ByteArray(length)
            var got = 0
            while (got < length) {
                val n = f.read(out, got, length - got)
                if (n <= 0) break
                got += n
            }
            out
        } catch (t: Throwable) {
            ByteArray(length)
        }
    }
}
